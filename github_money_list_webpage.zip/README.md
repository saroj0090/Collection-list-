# Monthly Money List — GitHub Pages

## Publish it

1. Create a GitHub account.
2. Create a new repository, for example `money-list`.
3. Upload `index.html`.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select **main** and **/(root)**, then Save.
7. GitHub will give you a public URL such as:
   `https://YOUR-USERNAME.github.io/money-list/`

## Update the list

Open `index.html` on GitHub and edit the `data` section.

Example:
```js
july:[
  ["Lucky bhaina",300],
  ["Batu bhai",300]
]
```

Change names/amounts, commit the change, and the public webpage updates.

For a simpler editing method, Google Sheets is better. This GitHub page is intended mainly as a clean public display.
